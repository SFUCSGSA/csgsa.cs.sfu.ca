require(ggplot2)
setwd("/Users/mroth/Dropbox/School/ggplot workshop")
load("spec50ms.Rdat")

summary(spec50ms)

p = ggplot(data=spec50ms, aes(x = (DATA_CACHE_MISSES/DATA_CACHE_ACCESSES), y = RETIRED_INSTRUCTIONS))
print(p+geom_point())

print(p+geom_point(alpha=0.1))

print(p+geom_point(aes(color=PROG), size=1, alpha=0.2))

print(p+geom_point(aes(color=PROG), size=1, alpha=0.2) + facet_wrap(~PROG))

summary(spec50ms)

print(p+geom_point(aes(color= DATA_CACHE_REFILLS.ALL), size=1, alpha=0.2) + facet_wrap(~PROG))

print(p+geom_point(aes(color= FRAME), size=1, alpha=0.2) + facet_wrap(~PROG))

p = ggplot(data=spec50ms, aes(x=FRAME, y=RETIRED_INSTRUCTIONS))
print(p + geom_line() + facet_wrap(~PROG))
print(p + geom_line(aes(color=DATA_CACHE_ACCESSES)) + facet_wrap(~PROG))
print(p + geom_line(aes(color=DATA_CACHE_MISSES)) + facet_wrap(~PROG))
print(p + geom_line(aes(color=DATA_CACHE_MISSES/DATA_CACHE_ACCESSES)) + facet_wrap(~PROG))

p = ggplot(data=subset(spec50ms,PROG=="hmmer"), aes(x=FRAME, y=RETIRED_INSTRUCTIONS))
print(p + geom_line(aes(color=DATA_CACHE_MISSES/DATA_CACHE_ACCESSES)))
