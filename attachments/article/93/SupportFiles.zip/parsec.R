require(ggplot2)

# File Loading
setwd("/Users/mroth/Dropbox/School/ggplot workshop")

parsec = read.delim(raw_dat, header = TRUE, sep = "\t")
parsec = data.frame(parsec)
load("parsec.Rdat")

# Canneal Large Example
canneal_large = subset(parsec, prog=="canneal" & input=="simlarge")

# this does nothing
canneal_large_plot = ggplot(data=canneal_large, aes(x=cores, y=speedup))
print(canneal_large_plot)

# add a line
canneal_large_plot = canneal_large_plot + geom_line()
print(canneal_large_plot)

# add straight line
canneal_large_plot = canneal_large_plot + geom_line(aes(x=cores, y=cores))
print(canneal_large_plot)

# Canneal Multiple
canneal = subset(parsec, prog=="canneal")

# A messy line
canneal_plot = ggplot(data=canneal) + geom_line(aes(x=cores, y=speedup))
print(canneal_plot)

# Separated by input
canneal_plot = ggplot(data=canneal) + geom_line(aes(x=cores, y=speedup, color=input))
print(canneal_plot)

# Add the linear scaling line back in
canneal_plot = ggplot(data=canneal, aes(x=cores)) + geom_line(aes(y=speedup, color=input)) + geom_line(aes(y=cores))
print(canneal_plot)

# A dark std dev band
canneal_plot = ggplot(data=canneal, aes(x=cores)) + geom_ribbon(aes(ymax = (speedup+stddev), ymin=(speedup-stddev), group=input))
print(canneal_plot)

# Make it transparent
canneal_plot = ggplot(data=canneal, aes(x=cores)) + geom_ribbon(aes(ymax = (speedup+stddev), ymin=(speedup-stddev), group=input), alpha=0.2)
print(canneal_plot)

# Add the lines again
canneal_plot = canneal_plot + geom_line(aes(y=speedup, color=input)) + geom_line(aes(y=cores))
print(canneal_plot)

# All the data
parsec_plot = ggplot(data=parsec, aes(x=cores)) + geom_ribbon(aes(ymax = (speedup+stddev), ymin=(speedup-stddev), group=input), alpha=0.2) + geom_line(aes(y=speedup, color=input)) + geom_line(aes(y=cores))
print(parsec_plot)

# Try grouping
parsec_plot = ggplot(data=parsec, aes(x=cores, group = prog)) + geom_ribbon(aes(ymax = (speedup+stddev), ymin=(speedup-stddev), group=input), alpha=0.2) + geom_line(aes(y=speedup, color=input)) + geom_line(aes(y=cores))
print(parsec_plot)

# Want faceting
parsec_plot = ggplot(data=parsec, aes(x=cores)) + geom_ribbon(aes(ymax = (speedup+stddev), ymin=(speedup-stddev), group=input), alpha=0.2) + geom_line(aes(y=speedup, color=input)) + geom_line(aes(y=cores))
print(parsec_plot + facet_wrap(~prog))
